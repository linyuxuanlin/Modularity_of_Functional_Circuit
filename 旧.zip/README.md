# Modularity_of_Functional_Circuit

使用 Altium Designer 的片段摘录功能，将实现不同功能的电路模块化，增强复用，并减少日后的重复工作。

功能模块中的每个元件，均取自我个人的库：[Power_Lib_Altium](https://github.com/linyuxuanlin/Power_Lib_Altium)