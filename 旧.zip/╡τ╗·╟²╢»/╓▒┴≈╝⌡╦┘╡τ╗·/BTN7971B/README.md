# 基本参数

* Input: 7.2V to 20 V
* Current: 0 to 68 A

# 元器件选型

为了保险起见，BTN7971B 这个 MOS 管最好选择进口的。

